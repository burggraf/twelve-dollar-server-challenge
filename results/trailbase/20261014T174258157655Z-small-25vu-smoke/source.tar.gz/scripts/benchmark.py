#!/usr/bin/env python3
"""TrailBase local capacity runner. Keeps every attempt, including invalid/failed runs.

No credentials are included in argv, manifests, source snapshots, or output artifacts.
"""
import argparse
from datetime import datetime, timezone
import fcntl
import hashlib
import json
import math
import os
from pathlib import Path
import shutil
import subprocess
import tarfile
import threading
import time

ROOT = Path(__file__).resolve().parents[1]
COMPOSE = ['docker', 'compose', '-f', str(ROOT / 'services/trailbase/compose.yaml')]
TARGET = 'baas-trailbase-trailbase-1'
LOAD = 'baas-trailbase-load'
TIERS = {'small': (1, 2 * 1024**3), 'large': (4, 4 * 1024**3)}


def evaluate(summary, exit_code):
    try:
        metrics = summary['metrics']
        values = lambda name: metrics[name + '{phase:hold}']['values']
        count = values('http_reqs')['count']
        latency, errors, schema = values('http_req_duration'), values('request_errors'), values('schema_errors')
        numbers = [count, latency['p(95)'], latency['p(99)'], errors['rate'], schema['rate']]
        if not all(isinstance(v, (int, float)) and not isinstance(v, bool) and math.isfinite(v) for v in numbers):
            return 'invalid', 'non-finite/malformed hold metrics'
        if count <= 0 or count != int(count) or any(not 0 <= v <= 1 for v in [errors['rate'], schema['rate']]):
            return 'invalid', 'empty/malformed hold'
        if any(m['passes'] + m['fails'] != count for m in [errors, schema]):
            return 'invalid', 'incomplete response-validation samples'
    except (KeyError, TypeError, ValueError):
        return 'invalid', 'missing required hold evidence'
    if exit_code not in (0, 99):
        return 'invalid', f'load runner exited {exit_code}'
    passed = latency['p(95)'] < 500 and latency['p(99)'] < 1000 and errors['rate'] < .01 and schema['rate'] == 0
    if passed and exit_code != 0:
        return 'invalid', 'unexplained k6 threshold/runner failure'
    return ('pass', 'hold gates passed') if passed else ('fail', 'hold latency/error/schema gate failed')


def app_source_hash():
    directory = ROOT / 'services/trailbase'
    files = [directory / name for name in ['Dockerfile', 'entrypoint.sh', 'config.textproto']]
    files += list((directory / 'migrations').glob('*.sql'))
    files += [directory / 'app/Cargo.toml', directory / 'app/Cargo.lock']
    files += list((directory / 'app/src').glob('*.rs'))
    digest = hashlib.sha256()
    for path in sorted(files):
        digest.update(str(path.relative_to(ROOT)).encode() + b'\0' + path.read_bytes() + b'\0')
    return digest.hexdigest()


def verification_source_hash():
    digest = hashlib.sha256()
    files = [ROOT / 'seed/generate.mjs', ROOT / 'services/trailbase/run.sh']
    for name in ['scripts', 'bench', 'test']:
        files.extend(p for p in (ROOT / name).rglob('*') if p.is_file() and '__pycache__' not in p.parts)
    for path in sorted(files):
        digest.update(str(path.relative_to(ROOT)).encode() + b'\0' + path.read_bytes() + b'\0')
    return digest.hexdigest()


def command(argv, **kwargs):
    return subprocess.run(argv, cwd=ROOT, check=True, **kwargs)


def capture(argv):
    return command(argv, capture_output=True, text=True).stdout


def inspect(name):
    # Whitelist only; docker inspect's Config.Env must never enter a report.
    item = json.loads(capture(['docker', 'inspect', name]))[0]
    return {key: item.get(key) for key in ['Id', 'Image', 'RestartCount', 'State']} | {
        'limits': {key: item['HostConfig'].get(key) for key in ['NanoCpus', 'Memory', 'MemorySwap']},
        'source_sha256': item['Config'].get('Labels', {}).get('benchmark.source_sha256'),
    }


def snapshot(destination):
    paths = [ROOT / name for name in ['README.md', 'MASTER_PLAN.md', 'SPEC.md', 'schema.sql', '.gitignore', '.dockerignore']]
    for name in ['services/trailbase', 'runner', 'scripts', 'bench', 'test', 'contracts', '.github/workflows', 'seed']:
        if (ROOT / name).exists():
            paths.extend(p for p in (ROOT / name).rglob('*') if p.is_file()
                         and not any(part in ['target', '__pycache__', 'tsv'] for part in p.parts)
                         and p.name not in ['tokens.json'] and not p.name.startswith('feed.db')
                         and (not p.name.startswith('.env') or p.name == '.env.example'))
    with tarfile.open(destination / 'source.tar.gz', 'w:gz') as archive:
        for path in sorted(set(paths)):
            archive.add(path, arcname=str(path.relative_to(ROOT)), recursive=False)
    (destination / 'working-tree.patch').write_bytes(command(['git', 'diff', 'HEAD', '--binary'], capture_output=True).stdout)


def monitor(stop, destination):
    with (destination / 'resources.jsonl').open('w') as stream:
        while not stop.is_set():
            record = {'time': time.time()}
            try:
                for name in [TARGET, LOAD]:
                    result = subprocess.run(['docker', 'stats', '--no-stream', '--format', '{{json .}}', name],
                                            capture_output=True, text=True, timeout=10)
                    if result.returncode == 0 and result.stdout.strip():
                        record[name] = json.loads(result.stdout.strip())
                # macOS counters contain no process arguments/credentials. Preserve raw values.
                for key, argv in [('vm_stat', ['vm_stat']), ('swap', ['sysctl', 'vm.swapusage']), ('thermal', ['pmset', '-g', 'therm'])]:
                    result = subprocess.run(argv, capture_output=True, text=True, timeout=5)
                    record[key] = result.stdout + result.stderr
            except Exception as error:
                record['monitor_error'] = str(error)
            stream.write(json.dumps(record) + '\n')
            stream.flush()
            if 'monitor_error' in record: return
            stop.wait(3)


def resource_verdict(destination, started, smoke, load_after):
    records = [json.loads(line) for line in (destination / 'resources.jsonl').read_text().splitlines()]
    if not records:
        return 'missing monitoring samples'
    if any('monitor_error' in record for record in records):
        return 'resource monitor failed'
    if load_after and load_after['State'].get('OOMKilled'):
        return 'load generator OOM (not target capacity)'
    begin, end = (5, 25) if smoke else (210, 510)
    hold = [r for r in records if started + begin <= r['time'] < started + end]
    samples = [r[LOAD] for r in hold if LOAD in r]
    if not samples:
        return 'missing load-generator hold monitoring'
    times = [r['time'] for r in hold if LOAD in r]
    tolerance = 10 if smoke else 15
    if len(samples) < 3 or times[0] > started + begin + tolerance or times[-1] < started + end - tolerance or any(b - a > 15 for a, b in zip(times, times[1:])):
        return 'incomplete load-generator hold monitoring'
    saturated = 0
    for sample in samples:
        saturated = saturated + 1 if float(sample['CPUPerc'].rstrip('%')) >= 180 else 0
        if saturated >= 3:
            return 'load generator sustained >=90% of its 2-CPU budget'
        if float(sample['MemPerc'].rstrip('%')) >= 90:
            return 'load generator used >=90% of its memory budget'
    def swapouts(record):
        for line in record.get('vm_stat', '').splitlines():
            if line.startswith('Swapouts:'):
                return int(line.split(':')[1].strip().rstrip('.'))
        return None
    first, last = swapouts(records[0]), swapouts(records[-1])
    if first is None or last is None:
        return 'missing host swap counters'
    if last > first:
        return 'host swap-outs increased during this attempt'
    return None


def checksum_files(directory):
    lines = [f'{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.name}' for p in sorted(directory.iterdir()) if p.is_file() and p.name != 'SHA256SUMS']
    (directory / 'SHA256SUMS').write_text('\n'.join(lines) + '\n')


def attempt(vus, tier, smoke=False):
    run_id = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ') + f'-{tier}-{vus}vu' + ('-smoke' if smoke else '')
    local = ROOT / '.state/runs' / run_id
    local.mkdir(parents=True)
    destination = ROOT / 'results/trailbase' / run_id
    destination.mkdir(parents=True)
    snapshot(destination)
    env = {**os.environ, 'TIER': tier}
    with (destination / 'reset.log').open('w') as log:
        command(['bash', 'services/trailbase/run.sh', 'reset'], env=env, stdout=log, stderr=subprocess.STDOUT)
    before = inspect(TARGET)
    cpus, memory = TIERS[tier]
    expected_limits = {'NanoCpus': cpus * 10**9, 'Memory': memory, 'MemorySwap': memory}
    if before['limits'] != expected_limits or before['source_sha256'] != app_source_hash():
        raise RuntimeError('Serving image/source or enforced tier differs from the expected configuration; rebuild first')
    (destination / 'dataset.json').write_bytes((ROOT / '.state/trailbase/dataset.json').read_bytes())
    correctness = ROOT / '.state/trailbase/correctness.log'
    attestation_file = ROOT / '.state/trailbase/correctness-manifest.json'
    if not correctness.exists() or not attestation_file.exists():
        raise RuntimeError('Run the full correctness gate first')
    attestation = json.loads(attestation_file.read_text())
    if attestation['app_source_sha256'] != app_source_hash() or attestation['verification_source_sha256'] != verification_source_hash() or attestation['image'] != before['Image'] or attestation['limits'] != before['limits'] or attestation['log_sha256'] != hashlib.sha256(correctness.read_bytes()).hexdigest():
        raise RuntimeError('Correctness evidence is stale for the serving image/log')
    shutil.copyfile(correctness, destination / 'correctness.log')
    shutil.copyfile(attestation_file, destination / 'correctness-manifest.json')
    manifest = {'service': 'trailbase', 'version': '0.34.6', 'sdk': '0.6.1', 'tier': tier, 'vus': vus,
        'mode': 'smoke' if smoke else 'capacity', 'workload': 'baas-v1', 'started_utc': datetime.now(timezone.utc).isoformat(),
        'git_commit': capture(['git', 'rev-parse', 'HEAD']).strip(), 'git_status': capture(['git', 'status', '--porcelain']),
        'app_source_sha256': app_source_hash(), 'target_before': before,
        'docker': capture(['docker', 'version', '--format', 'Client={{.Client.Version}} Server={{.Server.Version}}']),
        'docker_vm': capture(['docker', 'info', '--format', 'OS={{.OperatingSystem}} Arch={{.Architecture}} CPUs={{.NCPU}} MemoryBytes={{.MemTotal}}']),
        'host': capture(['uname', '-sm']), 'host_memory_cpu': capture(['sysctl', 'hw.ncpu', 'hw.memsize', 'machdep.cpu.brand_string']),
        'orbstack_version': capture(['orb', 'version']),
        'cost': 'local hardware; cloud monthly cost/request not applicable',
        'auth': 'HS256 compatibility verification inside native WASM handlers; not native TrailBase login throughput',
        'path': 'k6 container -> TrailBase HTTP -> Rust WASM guest -> TrailBase database/transaction SDK -> SQLite',
        'limitations': ['Shared host/VM and storage cache; no dedicated-machine equivalence', 'Host thermal/background activity requires human review; see raw resources.jsonl'],
    }
    stop = threading.Event()
    thread = threading.Thread(target=monitor, args=(stop, local), daemon=True)
    started = time.time()
    thread.start()
    load_after = None
    try:
        argv = COMPOSE + ['run', '-T', '--no-deps', '--name', LOAD,
            '-e', f'VUS={vus}', '-e', f'SMOKE={int(smoke)}', '-e', f'SUMMARY=/state/runs/{run_id}/k6-summary.json',
            'k6', 'run', '--quiet', '--out', f'json=/state/runs/{run_id}/samples.json.gz', '/work/bench/baas.mjs']
        with (local / 'k6.log').open('w') as log:
            result = subprocess.run(argv, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT)
        load_after = inspect(LOAD)
    finally:
        stop.set()
        thread.join(timeout=30)
        subprocess.run(['docker', 'rm', '-f', LOAD], cwd=ROOT, capture_output=True)
    if thread.is_alive():
        raise RuntimeError('Resource monitor did not stop')
    summary_file = local / 'k6-summary.json'
    summary = json.loads(summary_file.read_text()) if summary_file.exists() else {}
    outcome, reason = evaluate(summary, result.returncode)
    # Anchor monitoring to actual container start, excluding any image download/creation delay.
    started = datetime.fromisoformat(load_after['State']['StartedAt'].replace('Z', '+00:00')).timestamp()
    resource_issue = resource_verdict(local, started, smoke, load_after)
    if resource_issue:
        outcome, reason = 'invalid', resource_issue
    after = inspect(TARGET)
    if outcome != 'invalid' and (after['State'].get('OOMKilled') or not after['State'].get('Running') or after['RestartCount'] != before['RestartCount']):
        outcome, reason = 'fail', 'target OOM/exit/restart during attempt'
    manifest.update(target_after=after, load_after=load_after, k6_exit_code=result.returncode,
                    result=outcome, reason=reason, finished_utc=datetime.now(timezone.utc).isoformat())
    for path in local.iterdir():
        shutil.copyfile(path, destination / path.name)
    (destination / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    metrics = summary.get('metrics', {})
    def values(name): return metrics.get(name, {}).get('values', {})
    latency = values('http_req_duration{phase:hold}')
    errors = values('request_errors{phase:hold}')
    count = values('http_reqs{phase:hold}').get('count', 0)
    compact = {'outcome': outcome, 'reason': reason, 'vus': vus, 'tier': tier, 'mode': manifest['mode'],
               'hold_requests': count, 'hold_rps': count / (20 if smoke else 300), 'latency_ms': latency,
               'request_errors': errors, 'schema_errors': values('schema_errors{phase:hold}')}
    (destination / 'summary.json').write_text(json.dumps(compact, indent=2) + '\n')
    (destination / 'report.md').write_text(f'''# TrailBase {tier} — {vus} VUs ({manifest['mode']})

Outcome: **{outcome}** — {reason}.

This is one local ARM64 OrbStack attempt, **not a maximum-capacity score**. {'Smoke only: shortened timing, not scored.' if smoke else 'Capacity attempt: see campaign.json for search/confirmation status.'}

- Hold requests: {count}; throughput: {compact['hold_rps']:.2f} requests/s.
- Hold p50/p95/p99: {latency.get('med', 'N/A')} / {latency.get('p(95)', 'N/A')} / {latency.get('p(99)', 'N/A')} ms.
- Contract/transport/status error rate: {errors.get('rate', 'N/A')}.
- Full endpoint summaries: `k6-summary.json`; all raw metric points: `samples.json.gz`.
- CPU/RAM/I/O/network, host VM/swap/thermal evidence: `resources.jsonl`.
- Hardware, actual cgroup limits, image IDs, auth, source revision and caveats: `manifest.json`.
- Canonical data: `dataset.json`; prior full correctness gate: `correctness.log`.
- Uncommitted source is retained in `source.tar.gz` and `working-tree.patch`; verify `SHA256SUMS`.
- Local hardware has no measured cloud monthly price; cost/request is not applicable.

Reproduce from the source snapshot with `bash services/trailbase/run.sh build`, `bash services/trailbase/run.sh test`, then `TIER={tier} bash services/trailbase/run.sh bench --vus {vus}{' --smoke' if smoke else ''}`. See `services/trailbase/README.md` and `contracts/BENCHMARK.md` for the frozen protocol and limitations.

Publication is local repository artifacts only. No push, release, upload, or service progression was performed. Human review/acceptance remains required.
''')
    checksum_files(destination)
    print(f'BENCHMARK_ATTEMPT_FINISHED {outcome} {vus}vu {destination.relative_to(ROOT)}: {reason}', flush=True)
    return outcome, str(destination.relative_to(ROOT))


def campaign(args, tier):
    history = []
    def run(vus):
        if len(history) >= args.max_attempts:
            raise RuntimeError('Campaign attempt budget reached; no final score')
        outcome, path = attempt(vus, tier)
        history.append({'vus': vus, 'outcome': outcome, 'path': path})
        save('in_progress')
        if outcome == 'invalid':
            raise RuntimeError('Invalid measurements: campaign paused, not treated as target capacity failure')
        return outcome == 'pass'
    campaign_file = ROOT / '.state/trailbase/campaign.json'
    def save(status, **extra):
        campaign_file.write_text(json.dumps({'tier': tier, 'status': status, 'attempts': history, **extra}, indent=2) + '\n')
    low, high = 0, min(2500, args.max_vus)
    try:
        while run(high):
            low = high
            if high == args.max_vus:
                save('upper_budget_passed_no_maximum', lower_bound_vus=low)
                return
            high = min(high * 2, args.max_vus)
        while high - low > (250 if high > 250 else 25):
            step = 250 if high > 250 else 25
            mid = ((low + high) // (2 * step)) * step
            mid = max(low + step, min(high - step, mid))
            if run(mid): low = mid
            else: high = mid
        while low > 0:
            holds = [run(low) for _ in range(3)]
            if all(holds):
                save('confirmed_pending_human_review', candidate_vus=low)
                return
            low -= 250 if low > 250 else 25
        save('no_passing_capacity')
    except BaseException as error:
        save('paused', reason=str(error))
        raise
    finally:
        if campaign_file.exists():
            destination = ROOT / 'results/trailbase' / (datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ') + f'-{tier}-campaign.json')
            shutil.copyfile(campaign_file, destination)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-hash', action='store_true')
    parser.add_argument('--attest-correctness', action='store_true')
    parser.add_argument('--smoke', action='store_true')
    parser.add_argument('--vus', type=int, default=25)
    parser.add_argument('--campaign', action='store_true')
    parser.add_argument('--max-vus', type=int, default=20000)
    parser.add_argument('--max-attempts', type=int, default=12)
    args = parser.parse_args()
    if args.source_hash:
        print(app_source_hash()); return
    if args.attest_correctness:
        serving = inspect(TARGET)
        if serving['source_sha256'] != app_source_hash():
            raise RuntimeError('Tests ran against a stale image; rebuild and rerun')
        log = ROOT / '.state/trailbase/correctness.log'
        attestation = {'app_source_sha256': app_source_hash(), 'verification_source_sha256': verification_source_hash(), 'image': serving['Image'], 'limits': serving['limits'],
                       'log_sha256': hashlib.sha256(log.read_bytes()).hexdigest(),
                       'completed_utc': datetime.now(timezone.utc).isoformat()}
        (log.parent / 'correctness-manifest.json').write_text(json.dumps(attestation, indent=2) + '\n')
        return
    if not 1 <= args.vus <= 20000 or not 25 <= args.max_vus <= 20000 or args.max_attempts < 1:
        parser.error('VU budget must be within 1..20,000 and attempt budget positive')
    if args.campaign and args.smoke:
        parser.error('Smoke runs cannot be capacity campaigns')
    tier = os.environ.get('TIER', 'small')
    if tier not in TIERS:
        parser.error('Unknown tier')
    lock_path = ROOT / '.state/trailbase/campaign.lock'
    with lock_path.open('w') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        if args.campaign: campaign(args, tier)
        else:
            outcome, _ = attempt(args.vus, tier, args.smoke)
            if outcome != 'pass': raise SystemExit(1)


if __name__ == '__main__':
    main()
