# BaaS workload v1: local OrbStack

This fork retains the five endpoints and exact JSON/errors in [SPEC.md](../SPEC.md), including its full golden suite. It replaces the SQLite-only runtime/submission rules with per-product native implementations. Physical schemas may adapt types/IDs and platform metadata; equivalent baseline indexes are allowed. No response/query-result caches, precomputed counters, or JWT-verification caches in application code. Platform caches/retries are disclosed, not represented as identical across products.

## Frozen local profiles

| Profile | Entire serving stack | Runtime threads (TrailBase) | k6 container |
|---|---|---|---|
| small | 1 CPU quota, 2 GiB RAM, no container swap | 1 | 2 CPU quota, 2 GiB RAM, no container swap |
| large | 4 CPU quota, 4 GiB RAM, no container swap | 4 | same |

Serving-stack limits include database, BaaS, adapter/functions, and ingress where applicable. TrailBase needs one container, so its cgroup enforces the whole budget. Other stacks must allocate limits whose totals fit the same tier, or use verified aggregate enforcement. The shared OrbStack VM and macOS overhead are outside these container budgets. Host paging is monitored; these are **not dedicated $12 cloud-VM equivalents**. Do not change global OrbStack settings or stop unrelated workloads without approval.

Current host inventory is recorded per run, not assumed from the planning document. Only native ARM64 results belong in the primary local track; emulation and managed-cloud results belong in separate tracks. Cold starts, image downloads, migrations, seeding, and correctness runs are outside scored HTTP latency. Ingress for TrailBase is direct HTTP/1.1 on the Compose network; no Nginx, TLS, or compression. Port 4000 is bound to host loopback only; admin port 4001 is loopback-only inside the service container and is not published.

## Data and identities

Canonical export: `node seed/generate.mjs <directory>`, with no changes to its application-data algorithm. TSV fields use tab/newline delimiters without CSV quoting. Import 50,000 users, 500,000 posts, and **2,016,005** unique likes; preserve all seed IDs, timestamps, text, and relationships. Canonical logical row hash is `738d11ab3164c13177e347f75038d1e80b43c64e754544a42d1c32bd8d7bcf1d`, computed from `users ORDER BY id`, `posts ORDER BY id`, `likes ORDER BY post_id,user_id`, each row joined by `|` and followed by LF. Tokens are time/key-dependent and excluded from this hash and all published artifacts.

The compatibility identity contract uses HS256 tokens for users 1–20,000, with required numeric expiry, positive decimal-string subject, and string username. Validation happens on every write request; auth precedes body/ID validation. Native login/refresh throughput is not measured. TrailBase verifies these tokens inside its WASM handlers and uses the signed subject for all writes; it is not measuring TrailBase's native login/session flow. Native Record API access is read-only, with direct writes denied. No BaaS admin credential is used by k6.

Each attempt stops the service, replaces **only application table contents**, verifies counts/FKs/full logical hash, then restarts and waits for storage health. Platform metadata remains intact. Test writes and previous attempts never carry into another attempt. Warm-up writes within the same attempt do carry into its hold; that rule is the same for every product. Import tooling may use offline native bulk import; the **timed application** must use the product's supported APIs.

## User journey and scoring

`bench/baas.mjs` uses the inherited closed-loop journey: feed, think 3–7 s, detail for a random feed item, think 3–8 s, 15% like probability, 2% create probability, idle 5–15 s. Initial VUs are staggered by 0–5 s. No deterministic random seed is claimed; report actual endpoint mix and repeat runs. The default timeout is 10 s, no client retry or redirects; disclosed platform-internal retries remain included in timings.

Each capacity attempt has a 30 s ramp to `min(1000, target)` VUs, 2 min warm hold, 60 s ramp to target, **5 min scored hold**, and 30 s drain. Graceful ramp-down/stop allowances are 10 s. The lower warm-up load when target <1,000 is the predefined fallback; a warm-up at a higher load than the candidate must not disqualify a low-capacity service. Report that fallback explicitly.

Requests are tagged by their **start time**. Only requests started in the hold are scored; their completed latency/error samples are retained even if they complete during drain. This differs from the inherited script's all-phase aggregate. Raw JSON metric points and whole-run summaries are retained too. Thresholds:

- Hold p95 < 500 ms and p99 < 1,000 ms, with no rounding before evaluation.
- Hold request-error rate < 1%. Unexpected status, transport failure, JSON parse failure, or invalid response counts as a request error, including 2xx responses k6 might otherwise accept.
- Successful-status responses with invalid schemas/content/order have a separate **zero-tolerance schema-error gate**.
- Nonempty hold samples; a missing metric, incomplete validation sample count, runner crash, or contradictory exit status is invalid—not a target-capacity failure.

All four endpoint latencies, counts, and error rates are reported. Feed responses must contain 20 unique posts in timestamp/ID descending order. Create and like checks validate actual body/identity/ID and first/repeat status semantics, not just a 2xx code. Fine-grained concurrency/persistence requirements are covered by the correctness suite, not inferred from load checks.

Search starts at 2,500 VUs, doubles until failure, then narrows to 250-VU steps (25 below 250). A candidate needs **three independent passing 5-minute holds**; confirmation failure steps down. This is stricter than the upstream single hold. Default local safety budgets are 20,000 VUs (unique-token pool) and 12 attempts. Passing an upper budget is only a lower bound; exhausting an attempt budget is a paused campaign, **not a maximum score**. Invalid attempts pause for investigation, never define the failing side of a capacity bracket. A campaign status of `confirmed_pending_human_review` still needs artifact/resource review and acceptance before advancing to PocketBase.

`--smoke` is explicitly unscored: 5 s ramp, 20 s hold, 5 s drain. It validates the real container/load/artifact pipeline, not maximum capacity or statistical stability.

## Resource evidence and invalidation

`resources.jsonl` retains periodic Docker CPU/RAM/I/O/network/PID samples plus raw macOS VM, swap, and thermal output. Both cgroup budgets are inspected, not just requested in YAML. A k6 gauge records the actual scenario start and anchors hold-window resource checks, excluding image-pull delay and VU initialization (container start alone is insufficient). The runner rejects load OOM, missing/broken/sparse hold monitoring, three consecutive hold samples at >=180% Docker CPU (90% of its 2-CPU quota), >=90% runner memory, or increasing host swap-out counters. These rules are fixed before capacity runs. Target OOM/restarts/outages are disclosed target outcomes, not discarded as outliers.

Monitoring cannot prove absence of unrelated CPU contention or thermal throttling. Review the raw thermal/VM data and host activity before accepting scores; a shared laptop is a limitation even when automatic checks pass. Do not run builds or other benchmarks during a capacity campaign. The orchestrator itself and metrics export add consistent overhead outside the serving cgroup. No power-loss durability equivalence is claimed: acknowledged writes must survive normal service restart; platform persistence settings and guarantees must be disclosed.

## Provenance and publication

Each `results/trailbase/<run-id>/` includes full k6 summary, raw compressed metric stream, resource samples, reset/correctness output, counts/hash, machine-readable summary, selected Docker state/limits, source snapshot, tracked patch, and SHA256 checksums. Source/image labels and correctness attestations must match before running. Docker environment dumps, platform bootstrap logs (which can contain generated credentials), JWTs, secret files, and database volumes are never published. Runtime/build inputs are pinned in Compose/Dockerfiles/Cargo.lock, including an apt snapshot for the shared runner.

Reports are local versioned repository artifacts first. Do not equate writing local files with an external push/release/public upload. Local hardware has no measured cloud monthly price; cloud cost/request is not applicable. The original upstream challenge results are not comparable entries. No later BaaS starts before the TrailBase outcome is published, reviewed, and accepted.
