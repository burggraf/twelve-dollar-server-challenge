"""Scoring must fail closed on incomplete or contradictory k6 evidence."""
import json
import tempfile
from pathlib import Path
import sys
import unittest
sys.path.insert(0, str(Path(__file__).resolve().parents[2] / 'scripts'))
from benchmark import evaluate, resource_verdict, scenario_started


def summary():
    return {'metrics': {
        'http_reqs{phase:hold}': {'values': {'count': 100}},
        'http_req_duration{phase:hold}': {'values': {'p(95)': 100, 'p(99)': 200}},
        'request_errors{phase:hold}': {'values': {'rate': 0, 'passes': 0, 'fails': 100}},
        'schema_errors{phase:hold}': {'values': {'rate': 0, 'passes': 0, 'fails': 100}},
    }}


class Scoring(unittest.TestCase):
    def test_resource_clock_uses_k6_scenario_start_not_container_creation(self):
        data = {'metrics': {'benchmark_scenario_start_ms': {'values': {'value': 1700000123456}}}}
        self.assertEqual(scenario_started(data), 1700000123.456)
        for invalid in [{}, {'metrics': {'benchmark_scenario_start_ms': {'values': {'value': float('nan')}}}}]:
            with self.assertRaises(ValueError): scenario_started(invalid)

    def test_accepts_complete_passing_hold(self):
        self.assertEqual(evaluate(summary(), 0)[0], 'pass')

    def test_limits_are_strict_and_bad_success_bodies_fail(self):
        for metric, key, value in [('http_req_duration{phase:hold}', 'p(95)', 500),
                                   ('http_req_duration{phase:hold}', 'p(99)', 1000),
                                   ('request_errors{phase:hold}', 'rate', .01),
                                   ('schema_errors{phase:hold}', 'rate', .001)]:
            data = summary()
            data['metrics'][metric]['values'][key] = value
            self.assertEqual(evaluate(data, 99)[0], 'fail')

    def test_incomplete_or_nonfinite_evidence_is_invalid(self):
        cases = [{}, summary(), summary(), summary()]
        cases[1]['metrics']['http_reqs{phase:hold}']['values']['count'] = 0
        cases[2]['metrics']['http_req_duration{phase:hold}']['values']['p(95)'] = float('nan')
        cases[3]['metrics']['request_errors{phase:hold}']['values']['fails'] = 99
        for data in cases:
            self.assertEqual(evaluate(data, 0)[0], 'invalid')

    def test_runner_crash_and_unexplained_exit_are_not_target_capacity_failures(self):
        self.assertEqual(evaluate(summary(), 137)[0], 'invalid')
        self.assertEqual(evaluate(summary(), 99)[0], 'invalid')

    def test_monitor_errors_fail_closed_even_with_other_samples_present(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory)
            rows = [{'time': i, 'vm_stat': 'Swapouts: 0.',
                     'baas-trailbase-load': {'CPUPerc': '10%', 'MemPerc': '10%'}} for i in [10, 15, 20]]
            log = path / 'resources.jsonl'
            log.write_text(''.join(json.dumps(row) + '\n' for row in rows))
            self.assertIsNone(resource_verdict(path, 0, True, None))
            rows[-1]['monitor_error'] = 'stats command timed out'
            log.write_text(''.join(json.dumps(row) + '\n' for row in rows))
            self.assertEqual(resource_verdict(path, 0, True, None), 'resource monitor failed')

    def test_sparse_monitoring_cannot_certify_a_hold(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory)
            rows = [{'time': 10, 'vm_stat': 'Swapouts: 0.',
                     'baas-trailbase-load': {'CPUPerc': '10%', 'MemPerc': '10%'}}]
            (path / 'resources.jsonl').write_text(json.dumps(rows[0]) + '\n')
            self.assertEqual(resource_verdict(path, 0, True, None), 'incomplete load-generator hold monitoring')

    def test_generator_cpu_saturation_and_host_swap_are_not_target_failures(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory)
            rows = [{'time': i, 'vm_stat': 'Swapouts: 0.',
                     'baas-trailbase-load': {'CPUPerc': '190%', 'MemPerc': '10%'}} for i in [10, 15, 20]]
            log = path / 'resources.jsonl'
            log.write_text(''.join(json.dumps(row) + '\n' for row in rows))
            self.assertIn('CPU budget', resource_verdict(path, 0, True, None))
            for row in rows: row['baas-trailbase-load']['CPUPerc'] = '10%'
            rows[-1]['vm_stat'] = 'Swapouts: 1.'
            log.write_text(''.join(json.dumps(row) + '\n' for row in rows))
            self.assertIn('swap-outs', resource_verdict(path, 0, True, None))


if __name__ == '__main__':
    unittest.main(verbosity=2)
