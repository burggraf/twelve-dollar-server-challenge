"""Host-side validation of real resolved Compose mounts; never prints secret values."""
import json
from pathlib import Path
import subprocess
import unittest

ROOT = Path(__file__).resolve().parents[2]


class ContainerIsolation(unittest.TestCase):
    def test_k6_cannot_read_signing_keys_or_private_service_state(self):
        config = json.loads(subprocess.check_output(
            ['docker', 'compose', '-f', str(ROOT / 'services/trailbase/compose.yaml'), '--profile', 'load', 'config', '--format', 'json'], text=True))
        load = config['services']['k6']
        mounts = {mount['target']: mount for mount in load['volumes']}
        self.assertEqual(set(mounts), {'/work/bench', '/tokens.json', '/runs'})
        self.assertTrue(mounts['/work/bench']['read_only'])
        self.assertTrue(mounts['/tokens.json']['read_only'])
        self.assertFalse(load.get('secrets'))
        self.assertFalse(load.get('privileged', False))
        self.assertEqual(load['mem_limit'], load['memswap_limit'])
        self.assertNotIn(str(ROOT), [mount['source'] for mount in load['volumes']])


if __name__ == '__main__':
    unittest.main(verbosity=2)
